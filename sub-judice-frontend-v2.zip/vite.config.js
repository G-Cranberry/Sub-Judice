import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// '@mock' points at the local copy of Shilpa's mock JSON (frontend/mock_data)
export default defineConfig({
  plugins: [react()],
  resolve: { alias: { '@mock': path.resolve(__dirname, 'mock_data') } },
  server: { port: 5173, fs: { allow: ['.'] } },
})
