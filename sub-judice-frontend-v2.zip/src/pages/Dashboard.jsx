import { useEffect, useState } from 'react'
import { ChevronRight, Scale, FileText, AlertTriangle } from 'lucide-react'
import { getCases, getCase, getHearings } from '../api'
import { useBusy } from '../BusyContext'
import StatusBadge from '../components/StatusBadge'

const TABS = [['summary', 'Case Summary'], ['proposal', 'AI Proposal'], ['triage', 'Triage']]
const fmt = (d) => (d ? new Date(d).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : '—')
const rupees = (n) => (n == null ? '—' : 'Rs ' + Number(n).toLocaleString('en-IN'))
const ROUTE = { PHYSICAL_COURT: 'Physical court', AI_REVIEW: 'AI review' }

export default function Dashboard({ query }) {
  const { track } = useBusy()
  const [cases, setCases] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [selected, setSelected] = useState(null)
  const [detail, setDetail] = useState(null)
  const [tab, setTab] = useState('summary')

  const load = () => {
    setLoading(true); setError(null)
    track(getCases())
      .then((list) => { setCases(list); if (list[0]) setSelected(list[0].id) })
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false))
  }
  useEffect(load, [])

  useEffect(() => {
    if (!selected) return
    setTab('summary')
    track(Promise.all([getCase(selected), getHearings(selected)]))
      .then(([d, h]) => {
        const upcoming = h.filter((x) => new Date(x.scheduled_at) >= new Date()).sort((a, b) => a.scheduled_at.localeCompare(b.scheduled_at))
        setDetail({ ...d, nextHearing: upcoming[0] || null })
      })
      .catch((e) => setError(e.message))
  }, [selected])

  const q = query.trim().toLowerCase()
  const shown = cases.filter((c) => !q || [c.title, c.case_number, c.claimant_name, c.respondent_name].join(' ').toLowerCase().includes(q))
  const urgent = cases.filter((c) => c.triage.urgency_level === 'HIGH').length

  return (
    <>
      <section className="hero">
        <h1 className="serif">Justice at your fingertips.</h1>
        <p>{cases.length} cases in the queue, {urgent} urgent. AI suggests, people decide.</p>
      </section>

      {error && <div className="error" role="alert"><AlertTriangle size={18} /> {error} <button onClick={load}>Try again</button></div>}

      <div className="grid">
        <section className="panel">
          <div className="panel-head"><Scale size={26} strokeWidth={1.5} /><h3 className="serif">Current Cases</h3><span className="pill">{shown.length} active</span></div>
          {loading && <p className="muted pad">Loading cases…</p>}
          {!loading && shown.length === 0 && <p className="muted pad">No cases match “{query}”. Clear the search to see all cases.</p>}
          <ul className="cases">
            {shown.map((c) => (
              <li key={c.id}>
                <button className={'case-row' + (c.id === selected ? ' sel' : '')} onClick={() => setSelected(c.id)}>
                  <span className="cid"><b>{c.case_number}</b><small>{c.case_type}</small></span>
                  <span className="ctitle"><b>{c.title}</b><small>Urgency {c.triage.urgency_score} · {c.triage.urgency_level}</small></span>
                  <StatusBadge status={c.status} /><ChevronRight size={18} />
                </button>
              </li>
            ))}
          </ul>
        </section>

        <section className="panel">
          {!detail ? <p className="muted pad">Select a case to see its details.</p> : <Detail d={detail} tab={tab} setTab={setTab} />}
        </section>
      </div>
    </>
  )
}

function Detail({ d, tab, setTab }) {
  const { case: c, proposal, nextHearing } = d
  return (
    <>
      <div className="panel-head"><FileText size={26} strokeWidth={1.5} /><h3 className="serif">Case File</h3></div>
      <h2 className="serif case-title">{c.title}</h2>
      <p className="muted">{c.case_number} · {c.case_type} · {c.claimant_name} vs {c.respondent_name}</p>
      <div className="tabs" role="tablist">
        {TABS.map(([k, label]) => <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>)}
      </div>

      {tab === 'summary' && (
        <div className="summary">
          <dl>
            <dt>Filed on</dt><dd>{fmt(c.filed_at)}</dd>
            <dt>Deadline</dt><dd>{fmt(c.deadline)}</dd>
            <dt>Next hearing</dt><dd>{nextHearing ? fmt(nextHearing.scheduled_at) + ', ' + nextHearing.room : 'None scheduled'}</dd>
            <dt>Claim amount</dt><dd>{rupees(c.claim_amount)}</dd>
            <dt>Route</dt><dd>{ROUTE[c.route] || '—'}{c.override && ' (staff override)'}</dd>
            <dt>Status</dt><dd><StatusBadge status={c.status} /></dd>
          </dl>
          <div><h4 className="serif">Key points</h4><p>{c.summary}</p></div>
        </div>
      )}

      {tab === 'proposal' && (proposal ? (
        <div className="proposal">
          <div className="disclaimer"><AlertTriangle size={16} /> {proposal.disclaimer}</div>
          <h4 className="serif">Proposed resolution</h4><p>{proposal.proposed_resolution}</p>
          <h4 className="serif">Reasoning</h4><ul>{proposal.reasoning.map((r, i) => <li key={i}>{r}</li>)}</ul>
          <p className="muted">Suggested relief: {proposal.suggested_relief} · AI confidence {Math.round(proposal.confidence * 100)}% · Status: {proposal.status.replace('_', ' ')}</p>
        </div>
      ) : <p className="muted pad">No AI proposal for this case. {c.route === 'PHYSICAL_COURT' ? 'It is routed to a physical court.' : 'It has not been generated yet.'}</p>)}

      {tab === 'triage' && (
        <div className="triage">
          {[['Urgency', c.triage.urgency_score], ['Complexity', c.triage.complexity_score]].map(([l, v]) => (
            <div key={l} className="meter"><span>{l} <b>{v}</b></span><i style={{ width: v + '%' }} /></div>
          ))}
          <p className="muted">AI confidence {Math.round(c.triage.confidence * 100)}%{c.triage.hard_flags.length > 0 && ' · Flags: ' + c.triage.hard_flags.join(', ').replaceAll('_', ' ')}</p>
          <h4 className="serif">Why this score</h4><ul>{c.triage.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
          {c.override && <div className="disclaimer">Overridden by staff ({c.override.by_user_id}): {c.override.reason}</div>}
        </div>
      )}
    </>
  )
}
