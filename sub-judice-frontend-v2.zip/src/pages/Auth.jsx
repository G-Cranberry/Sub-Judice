import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Scale, Info } from 'lucide-react'
import { demoLogin } from '../api'
import { useAuth } from '../AuthContext'
import { useBusy } from '../BusyContext'
import ProcessingOwl from '../components/ProcessingOwl'

const ROLES = [['filer', 'Citizen (files cases)'], ['court_staff', 'Court staff'], ['student', 'Law student'], ['lawyer', 'Lawyer'], ['judge', 'Senior judge'], ['notary', 'Notary']]

export default function Auth({ mode }) {
  const signup = mode === 'signup'
  const { login } = useAuth()
  const { busy, track } = useBusy()
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'court_staff' })
  const [errors, setErrors] = useState({})
  const [fail, setFail] = useState('')
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value })

  const validate = () => {
    const e = {}
    if (signup && f.name.trim().length < 2) e.name = 'Enter your full name.'
    if (!/^\S+@\S+\.\S+$/.test(f.email)) e.email = 'Enter a valid email address.'
    if (f.password.length < 6) e.password = 'Use at least 6 characters.'
    return e
  }

  const submit = async (ev) => {
    ev.preventDefault()
    const e = validate(); setErrors(e); setFail('')
    if (Object.keys(e).length) return
    try {
      const u = await track(demoLogin(f.role)) // password is never sent or stored
      login(signup ? { ...u, name: f.name.trim() } : u)
    } catch (err) { setFail(err.message) }
  }

  return (
    <div className="auth">
      <aside className="auth-side">
        <Scale size={44} strokeWidth={1.3} color="#d9a441" />
        <h1 className="serif">Courtroom intelligence, with human judgment.</h1>
        <p>AI suggests. People decide.</p>
      </aside>
      <main className="auth-main">
        <form className="auth-card" onSubmit={submit} noValidate>
          <h2 className="serif">{signup ? 'Create your account' : 'Welcome back'}</h2>
          <p className="muted">{signup ? 'Pick the role you will use in court.' : 'Log in to your Sub-Judice workspace.'}</p>
          <div className="note"><Info size={16} /> Prototype sign-in: no password is checked or stored. Your role decides what you see.</div>

          {signup && <label className="field">Full name<input value={f.name} onChange={set('name')} autoComplete="name" />{errors.name && <small>{errors.name}</small>}</label>}
          <label className="field">Email<input type="email" value={f.email} onChange={set('email')} autoComplete="email" />{errors.email && <small>{errors.email}</small>}</label>
          <label className="field">Password<input type="password" value={f.password} onChange={set('password')} autoComplete={signup ? 'new-password' : 'current-password'} />{errors.password && <small>{errors.password}</small>}</label>
          <label className="field">Role<select value={f.role} onChange={set('role')}>{ROLES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>

          {fail && <div className="error" role="alert">{fail}</div>}
          <div className="owl-anchor">
            <ProcessingOwl active={busy} message={signup ? 'Creating account' : 'Signing you in'} />
            <button className="primary" disabled={busy}>{signup ? 'Create account' : 'Log in'}</button>
          </div>
          <p className="switch">{signup ? <>Already registered? <Link to="/login">Log in</Link></> : <>New here? <Link to="/signup">Create an account</Link></>}</p>
        </form>
      </main>
    </div>
  )
}
