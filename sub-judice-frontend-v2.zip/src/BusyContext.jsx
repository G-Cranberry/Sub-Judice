import { createContext, useContext, useState, useCallback } from 'react'

// "busy" is true while ANY tracked request is running. The owl listens to it.
// Usage anywhere:  const { track } = useBusy();  const data = await track(getCases())
const BusyCtx = createContext(null)

export function BusyProvider({ children }) {
  const [count, setCount] = useState(0)
  const track = useCallback(async (promise) => {
    setCount((c) => c + 1)
    try { return await promise } finally { setCount((c) => c - 1) }
  }, [])
  return <BusyCtx.Provider value={{ busy: count > 0, track }}>{children}</BusyCtx.Provider>
}
export const useBusy = () => useContext(BusyCtx)
