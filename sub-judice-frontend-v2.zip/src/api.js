// EVERY backend call lives in this file. Flip USE_MOCK to false when Aditya's backend is ready.
import casesData from '@mock/cases.json'
import proposalsData from '@mock/proposals.json'
import evidenceData from '@mock/evidence.json'
import hearingsData from '@mock/hearings.json'
import usersData from '@mock/users.json'

export const USE_MOCK = true
const BASE = 'http://localhost:8000'
const wait = (ms = 700) => new Promise((r) => setTimeout(r, ms)) // fake network delay so the owl is visible

async function http(path, options) {
  const res = await fetch(BASE + path, options)
  const body = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(body.message || 'Request failed (' + res.status + ')')
  return body
}

export async function getCases() {
  if (USE_MOCK) {
    await wait()
    return [...casesData.cases].sort((a, b) => b.triage.urgency_score - a.triage.urgency_score)
  }
  return (await http('/cases')).cases
}

// returns { case, evidence, proposal }
export async function getCase(id) {
  if (USE_MOCK) {
    await wait(600)
    const c = casesData.cases.find((x) => x.id === id)
    if (!c) throw new Error('Case not found')
    return {
      case: c,
      evidence: evidenceData.evidence.filter((e) => e.case_id === id),
      proposal: proposalsData.proposals.find((p) => p.case_id === id) || null,
    }
  }
  return http('/cases/' + id)
}

export async function getHearings(caseId) {
  if (USE_MOCK) return hearingsData.hearings.filter((h) => h.case_id === caseId)
  return (await http('/hearings?case_id=' + caseId)).hearings
}

// Prototype only: picks a demo user, this is NOT real login.
export function getDemoUser(role = 'court_staff') {
  return usersData.users.find((u) => u.role === role) || usersData.users[0]
}

// POST /auth/demo-login  { role } -> { user }. Prototype only: the contract has no sign-up or password endpoint.
export async function demoLogin(role) {
  if (USE_MOCK) { await wait(900); return getDemoUser(role) }
  const body = await http('/auth/demo-login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ role }) })
  return body.user
}
