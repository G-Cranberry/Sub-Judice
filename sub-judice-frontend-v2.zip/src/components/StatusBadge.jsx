const LABELS = {
  filed: 'Filed', triaged: 'Triaged', routed_court: 'Physical court',
  ai_review: 'AI review', under_review: 'Under review', resolved: 'Resolved',
}
export default function StatusBadge({ status }) {
  return <span className={'badge b-' + status}>{LABELS[status] || status}</span>
}
