import { NavLink } from 'react-router-dom'
import { Home, FilePlus2, FolderOpen, Gavel, Scale, LogOut } from 'lucide-react'

const LINKS = [
  { to: '/', label: 'Dashboard', icon: Home },
  { to: '/file', label: 'File a Case', icon: FilePlus2 },
  { to: '/queue', label: 'Case Queue', icon: FolderOpen },
  { to: '/review', label: 'Judge Review', icon: Gavel },
]

export default function Sidebar({ user, onLogout }) {
  return (
    <aside className="sidebar">
      <div className="brand"><Scale size={38} strokeWidth={1.4} color="#d9a441" /><h2>SUB-JUDICE</h2><em>AI. Law. Justice.</em></div>
      <nav>
        {LINKS.map(({ to, label, icon: Icon }) => (
          <NavLink key={to} to={to} end className={({ isActive }) => 'nav' + (isActive ? ' active' : '')}>
            <Icon size={20} /> {label}
          </NavLink>
        ))}
      </nav>
      <div className="motto serif">Justice,<br />for everyone.</div>
      <div className="user"><span className="avatar">{user.name[0]}</span><div><b>{user.name}</b><small>{user.role.replace('_', ' ')}</small></div><button className="logout" onClick={onLogout} aria-label="Log out"><LogOut size={18} /></button></div>
    </aside>
  )
}
