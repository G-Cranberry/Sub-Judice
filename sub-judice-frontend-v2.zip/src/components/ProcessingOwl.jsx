// Small chibi owl mascot (React component). Props: active (show/hide), message (bubble text).
// Sits on top of its parent (parent needs className "owl-anchor") and appears only while active.
export default function ProcessingOwl({ active, message = 'Working' }) {
  return (
    <div className={'owl-wrap' + (active ? ' show' : '')} role="status" aria-live="polite" aria-hidden={!active}>
      <svg className="owl" viewBox="0 0 64 64" width="52" height="52" aria-hidden="true">
        <path d="M14 20 L12 6 L26 14Z M50 20 L52 6 L38 14Z" fill="#8a6446" />
        <ellipse className="wing-l" cx="11" cy="38" rx="5" ry="11" fill="#7b573b" />
        <ellipse className="wing-r" cx="53" cy="38" rx="5" ry="11" fill="#7b573b" />
        <ellipse cx="32" cy="35" rx="22" ry="21" fill="#a47c58" />
        <ellipse cx="32" cy="42" rx="13" ry="12" fill="#f5e7cf" />
        <g className="eyes">
          <circle cx="23.5" cy="29" r="8" fill="#fff" stroke="#3a2c20" strokeWidth="1.5" />
          <circle cx="40.5" cy="29" r="8" fill="#fff" stroke="#3a2c20" strokeWidth="1.5" />
          <circle cx="24.5" cy="30" r="4.2" fill="#1d1a2b" /><circle cx="39.5" cy="30" r="4.2" fill="#1d1a2b" />
          <circle cx="26" cy="28.4" r="1.4" fill="#fff" /><circle cx="41" cy="28.4" r="1.4" fill="#fff" />
        </g>
        <circle cx="15" cy="37" r="2.6" fill="#f2a0a0" opacity=".6" /><circle cx="49" cy="37" r="2.6" fill="#f2a0a0" opacity=".6" />
        <path d="M29.5 35 L34.5 35 L32 39.5Z" fill="#e0a73c" />
        {/* advocate bands: dark collar with two white tabs */}
        <rect x="23" y="43" width="18" height="9" rx="2.5" fill="#1b2340" />
        <rect x="28.2" y="43" width="3.3" height="9" fill="#fff" /><rect x="32.5" y="43" width="3.3" height="9" fill="#fff" />
        <ellipse cx="25" cy="57" rx="5" ry="2.6" fill="#e0a73c" /><ellipse cx="39" cy="57" rx="5" ry="2.6" fill="#e0a73c" />
      </svg>
      <div className="owl-bubble">{message}<span className="dots"><i>.</i><i>.</i><i>.</i></span></div>
    </div>
  )
}
