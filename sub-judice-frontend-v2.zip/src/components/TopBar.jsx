import { Search, Bell, Moon, Sun } from 'lucide-react'
import ProcessingOwl from './ProcessingOwl'

export default function TopBar({ user, query, onQuery, busy, theme, onTheme }) {
  const h = new Date().getHours()
  const greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening'
  return (
    <header className="topbar">
      <h1 className="serif greet">{greet}, {user.name.split(' ')[0]}</h1>
      <div className="searchwrap owl-anchor">
        <ProcessingOwl active={busy} message="Reviewing cases" />
        <label className="search"><Search size={20} />
          <input value={query} onChange={(e) => onQuery(e.target.value)} placeholder="Search cases…" aria-label="Search cases" />
        </label>
      </div>
      <button className="icon-btn" aria-label="Notifications"><Bell size={20} /></button>
      <button className="icon-btn" onClick={onTheme} aria-label="Toggle theme">{theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}</button>
    </header>
  )
}
