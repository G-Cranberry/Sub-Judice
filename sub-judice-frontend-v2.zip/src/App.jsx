import { useState, useEffect } from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import TopBar from './components/TopBar'
import Dashboard from './pages/Dashboard'
import Auth from './pages/Auth'
import { useBusy } from './BusyContext'
import { useAuth } from './AuthContext'

const Soon = ({ title, phase }) => (
  <section className="panel"><h3 className="serif">{title}</h3><p className="muted">Coming in {phase}.</p></section>
)

export default function App() {
  const { user, logout } = useAuth()
  const { busy } = useBusy()
  const [query, setQuery] = useState('')
  const [theme, setTheme] = useState('light')
  useEffect(() => { document.documentElement.dataset.theme = theme }, [theme])

  if (!user) return (
    <Routes>
      <Route path="/signup" element={<Auth mode="signup" />} />
      <Route path="*" element={<Auth mode="login" />} />
    </Routes>
  )

  return (
    <div className="app">
      <Sidebar user={user} onLogout={logout} />
      <main>
        <TopBar user={user} query={query} onQuery={setQuery} busy={busy} theme={theme} onTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')} />
        <Routes>
          <Route path="/" element={<Dashboard query={query} />} />
          <Route path="/file" element={<Soon title="File a Case" phase="Phase 5" />} />
          <Route path="/queue" element={<Soon title="Case Queue" phase="Phase 4" />} />
          <Route path="/review" element={<Soon title="Judge Review" phase="Phase 7" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  )
}
