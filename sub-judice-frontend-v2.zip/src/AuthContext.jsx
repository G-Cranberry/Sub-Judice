import { createContext, useContext, useState } from 'react'

// PROTOTYPE ONLY: remembers who "logged in" in this browser. It is not real security.
const Ctx = createContext(null)
const KEY = 'sj_user'

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => { try { return JSON.parse(localStorage.getItem(KEY)) } catch { return null } })
  const login = (u) => { setUser(u); try { localStorage.setItem(KEY, JSON.stringify(u)) } catch {} }
  const logout = () => { setUser(null); try { localStorage.removeItem(KEY) } catch {} }
  return <Ctx.Provider value={{ user, login, logout }}>{children}</Ctx.Provider>
}
export const useAuth = () => useContext(Ctx)
